package com.example.courseworkitf.model;

public enum VehicleType {
    CAR, SCOOTER, LEGS, BIKE
}
