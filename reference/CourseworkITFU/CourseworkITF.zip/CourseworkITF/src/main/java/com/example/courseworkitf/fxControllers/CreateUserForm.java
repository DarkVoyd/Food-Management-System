package com.example.courseworkitf.fxControllers;

import javafx.scene.control.TextArea;
import javafx.scene.layout.Pane;

public class CreateUserForm {
    public Pane restaurantPane;
    public TextArea restaurantDescField;
}
