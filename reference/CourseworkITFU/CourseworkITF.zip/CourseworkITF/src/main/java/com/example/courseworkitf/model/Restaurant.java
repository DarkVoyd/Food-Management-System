package com.example.courseworkitf.model;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public final class Restaurant extends User{
    private String description;
    private String address;
    private LocalDateTime happyHours;
    private String cuisineType;
    private double rating;
    private boolean isOpen;
    private LocalTime openingTime;
    private LocalTime closingTime;
    private List<Dish> menu;

    public Restaurant(String username, String password, String phoneNum, String description, String address, LocalDateTime happyHours) {
        super(username, password, phoneNum);
        this.description = description;
        this.address = address;
        this.happyHours = happyHours;
        this.isOpen = true;
    }

    public Restaurant(String username, String password, String phoneNum, String description, String address, LocalDateTime happyHours, String cuisineType, LocalTime openingTime, LocalTime closingTime) {
        super(username, password, phoneNum);
        this.description = description;
        this.address = address;
        this.happyHours = happyHours;
        this.cuisineType = cuisineType;
        this.openingTime = openingTime;
        this.closingTime = closingTime;
        this.isOpen = true;
    }
}
