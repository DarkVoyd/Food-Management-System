package com.example.courseworkitf.model;

public enum OrderStatus {
    PENDING, CONFIRMED, PREPARING, READY_FOR_PICKUP, IN_DELIVERY, DELIVERED, CANCELLED
}
