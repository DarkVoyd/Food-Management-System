package com.example.courseworkitf.model;

import java.time.LocalDate;

public class Driver extends User{
    private String name;
    private String surname;
    private String driverLicence;
    private VehicleType vehicleType;
    private LocalDate birthDate;
    private boolean isAvailable;
    private double rating;
    private int totalDeliveries;
    private String vehiclePlateNumber;

    public Driver(String username, String password, String phoneNum, String driverLicence, VehicleType vehicleType, LocalDate birthDate) {
        super(username, password, phoneNum);
        this.driverLicence = driverLicence;
        this.vehicleType = vehicleType;
        this.birthDate = birthDate;
        this.isAvailable = true;
    }

    public Driver(String username, String password, String phoneNum, String driverLicence, VehicleType vehicleType, LocalDate birthDate, String vehiclePlateNumber) {
        super(username, password, phoneNum);
        this.driverLicence = driverLicence;
        this.vehicleType = vehicleType;
        this.birthDate = birthDate;
        this.vehiclePlateNumber = vehiclePlateNumber;
        this.isAvailable = true;
    }
}
