package com.example.courseworkitf.model;

import java.util.List;

public class Dish
{
    private int id;
    private String title;
    private String description;
    private float price;
    private DishCategory category;
    private int preparationTimeMin;
    private boolean isAvailable;
    private String imageUrl;
    private float weight;
    private List<String> allergens;
    private int calories;
}
