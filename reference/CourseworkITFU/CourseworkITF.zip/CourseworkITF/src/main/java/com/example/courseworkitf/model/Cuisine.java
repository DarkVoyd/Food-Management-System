package com.example.courseworkitf.model;

public enum Cuisine {
    ITALIAN, CHINESE, JAPANESE, MEXICAN, INDIAN, AMERICAN, FRENCH, THAI, KOREAN, MEDITERRANEAN, LITHUANIAN
}
