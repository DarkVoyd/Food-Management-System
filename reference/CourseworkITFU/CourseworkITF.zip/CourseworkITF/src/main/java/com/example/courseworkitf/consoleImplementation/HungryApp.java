package com.example.courseworkitf.consoleImplementation;

public class HungryApp implements CoreApp {
    @Override
    public void sendComplaint(String messageText, String email) {
        //rasyciau logika kaip nusiskundima issaugoti
    }
}
