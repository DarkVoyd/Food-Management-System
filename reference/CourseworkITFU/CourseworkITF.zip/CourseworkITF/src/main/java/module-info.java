module com.example.courseworkitf {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.j;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires org.kordamp.bootstrapfx.core;

    opens com.example.courseworkitf to javafx.fxml;
    exports com.example.courseworkitf;
    opens com.example.courseworkitf.fxControllers to javafx.fxml;
    exports com.example.courseworkitf.fxControllers;
}