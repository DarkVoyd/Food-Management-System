package com.example.courseworkitf.model;

public enum DishCategory {
    APPETIZER, MAIN_COURSE, DESSERT, DRINK, SALAD, SOUP, SIDE_DISH, SNACK
}
