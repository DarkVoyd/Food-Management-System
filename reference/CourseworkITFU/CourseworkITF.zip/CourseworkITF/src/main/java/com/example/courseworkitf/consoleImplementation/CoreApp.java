package com.example.courseworkitf.consoleImplementation;

public interface CoreApp {
    public void sendComplaint(String messageText, String email);
}
